#ifndef __USB_DEV_HPP_HEADER__
#define __USB_DEV_HPP_HEADER__

#include <iostream>
#include "ControlI2C.h"
#include "ErrorType.h" 

void USB_DEV_INIT(void);
void USB_DEV_CONFIG_I2C(void); 

#endif

