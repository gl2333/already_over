#ifndef __TEST_LIST_CPP_HEADER__
#define __TEST_LIST_CPP_HEADER__

#include<iostream>
using namespace std;

#include "test.hpp"

typedef struct {
	string menu_display;
	string select_string;
	void (*function_name)();
}TestFunction;

#define FUNCTION_NUM (60)
extern TestFunction g_function_table[];

#endif

