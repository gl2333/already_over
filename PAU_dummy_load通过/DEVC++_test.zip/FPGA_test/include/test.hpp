#ifndef __TEST_HPP_HEADER__
#define __TEST_HPP_HEADER__

#include<stdio.h>
#include<iostream>
#include <string>
using namespace std;

void test_1_1 (void);
void test_1_2 (void);
void test_1_3 (void);
void test_1_4 (void);
void test_1_5 (void);
void test_1_6 (void);
void test_1_7 (void);
void test_1_8 (void);
void test_1_9 (void);
void test_1_10(void);
void test_2_1 (void);
void test_2_2 (void);
void test_2_3 (void);
void test_2_4 (void);
void test_2_5 (void);
void test_2_6 (void);
void test_2_7 (void);
void test_2_8 (void);
void test_2_9 (void);
void test_2_10(void);
void test_3_1 (void);
void test_3_2 (void);
void test_3_3 (void);
void test_3_4 (void);
void test_3_5 (void);
void test_3_6 (void);
void test_3_7 (void);
void test_3_8 (void);
void test_3_9 (void);
void test_3_10(void);
void test_4_1 (void);
void test_4_2 (void);
void test_4_3 (void);
void test_4_4 (void);
void test_4_5 (void);
void test_4_6 (void);
void test_4_7 (void);
void test_4_8 (void);
void test_4_9 (void);
void test_4_10(void);
void test_5_1 (void);
void test_5_2 (void);
void test_5_3 (void);
void test_5_4 (void);
void test_5_5 (void);
void test_5_6 (void);
void test_5_7 (void);
void test_5_8 (void);
void test_5_9 (void);
void test_5_10(void);
void test_6_1 (void);
void test_6_2 (void);
void test_6_3 (void);
void test_6_4 (void);
void test_6_5 (void);
void test_6_6 (void);
void test_6_7 (void);
void test_6_8 (void);
void test_6_9 (void);
void test_6_10(void);

#endif
